import re

def wrong_contact(contact):
    contact_str = str(contact)
    if len(contact_str) != 10:
        return "Contact number must be 10 digits long."
    elif not contact_str.isdigit():
        return "Contact number should contain only digits."
    else:
        return True  # Indicates that the contact number is valid

def valid_name(name):
    
    if not re.match(r'^[a-zA-Z\s]{1,15}$', name):
        print("Name should only contain letters and should be between 1 to 15 characters long.")
        return False
    else:
        return True

def password_check(password): 

    '''to check the password'''
     # Check the length of the password
    if len(password) < 8 or len(password) > 15:
        return False

    has_number = False
    has_alpha = False
    has_symbol = False
    
    for char in password:
        if char.isdigit():
            has_number = True
        elif char.isalpha():
            has_alpha = True
        elif not char.isalnum():  # Check for special characters
            has_symbol = True
        
        # If all conditions are met, we can return True early
        if has_number and has_alpha and has_symbol:
            return True

    return False  # R
    
def is_valid_email(email):

     # Check if the email ends with '@gmail.com' and has characters before it
    return email.lower().endswith('@gmail.com') and len(email) > len('@gmail.com')
