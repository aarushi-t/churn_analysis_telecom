import pymysql 
from services import db_connection

con, cursor = db_connection.connect_to_database() 

def open_account(user_name, user_password, user_email, user_contact):
    """Insert a new user into the user_details table."""
    con, cursor = db_connection.connect_to_database()
    
    insert_query = '''INSERT INTO user_details (user_name, user_password, user_email, user_contact) 
                      VALUES (%s, %s, %s, %s)'''
    
    cursor.execute(insert_query, (user_name, user_password, user_email, user_contact))
    con.commit()
    print("User  account created successfully.")
    
def account_check(user_email, user_contact):
    """Check if a user with the given email or contact exists in the user_details table."""
    con, cursor = db_connection.connect_to_database()
    
    check_query = '''SELECT * FROM user_details WHERE user_email = %s OR user_contact = %s'''
    try:
        cursor.execute(check_query, (user_email, user_contact))
        result = cursor.fetchone()  # Fetch one record
        return result is not None  # Returns True if user exists, False otherwise
    except pymysql.Error as e:
        print(f"Error checking account: {e}")
        return False
    finally:
        db_connection.close_connection(con)

def get_user_by_email(user_input):

    """Fetch user data by email."""

    query = '''SELECT user_email FROM user_details WHERE user_email = %s'''
    cursor.execute(query,user_input)
    email= [row[0] for row in cursor.fetchall()]
    return email

def get_user_by_contact(user_input):

    """Fetch user data by contact number."""
    query = '''SELECT user_contact FROM user_details WHERE user_contact = %s '''
    cursor.execute(query,user_input)
    contact= [row[0] for row in cursor.fetchall()]
    return contact

def get_password_email(login_input):
    """Fetch user password by email."""
    query = '''SELECT user_password FROM user_details WHERE user_email = %s'''
    cursor.execute(query, (login_input))
    return cursor.fetchone()

def get_password_contact(login_input):
    """Fetch user password by email."""
    query = '''SELECT user_password FROM user_details WHERE user_contact = %s'''
    cursor.execute(query, (login_input))
    return cursor.fetchone()
