import streamlit as st
import pandas as pd
import plotly.express as px
from services import credentials_check, session, clean_data
from models import user_details
from views import demographic, geographic, service_used, account_info, churn_distribution
from algorithems import random_forest
from views import prediction_visual
from views import user_login

def main():
    session.init_session_state()

    if not st.session_state.get('logged_in', False):
        show_login_page()
    else:
        if session.check_session_validity():
            show_main_dashboard()
        else:
            show_login_page()

    try:
        # Clean the data
        df = clean_data.data_cleaning()
       
    except Exception as e:
        random_forest.logging.error(f"An error occurred: {e}")
        st.error("An error occurred while processing data. Please try again later.")
        return

def show_login_page():
    st.title("Welcome to Churn Analysis Dashboard")

    
    tab1, tab2 = st.tabs(["Login", "Register"])
    with tab1:
        st.header("Login")
        user_login.login()
        
    with tab2:
        st.header("📝 Register")
        user_login.signup()    
   
def show_main_dashboard():
    # Load and clean data
    clean_df = clean_data.data_cleaning()
    
    # Sidebar navigation
    st.sidebar.title(" Dashboard Options")
    
    # Logout button
    if st.sidebar.button("Logout"):
        session.end_session()
        st.session_state.logged_in = False
        # st.experimental_rerun()
    
    # Dashboard type selection
    dashboard_type = st.sidebar.radio(
        "Choose Dashboard Type",
        ["Overview", "Detailed Summary", "Predictions"]
    )
    
    # Route to appropriate dashboard
    if dashboard_type == "Overview":
        show_overview_dashboard(clean_df)
    elif dashboard_type == "Detailed Summary":
        show_detailed_summary_dashboard(clean_df)
    else:
        show_predictions_dashboard(clean_df)

def show_overview_dashboard(clean_df):
    st.title(" Overview Dashboard")
    
    # Key metrics
    col1, col2, col3, col4 = st.columns(4)
    with col1:
        st.metric("Total Customers", len(clean_df))
    with col2:
        churn_rate = (clean_df['Customer_Status'].value_counts(normalize=True).get('Churned', 0) * 100).round(2)
        st.metric("Churn Rate", f"{churn_rate}%")
    with col3:
        avg_tenure = clean_df['Tenure_in_Months'].mean().round(2)
        st.metric("Avg. Tenure (months)", avg_tenure)
    with col4:
        avg_revenue = clean_df['Total_Revenue'].mean().round(2)
        st.metric("Avg. Revenue", f"${avg_revenue}")

    # Churn Reasons Visualization
    churn_reasons = clean_df[clean_df['Customer_Status'] == 'Churned']['Churn_Reason'].value_counts()
    churn_reasons_df = churn_reasons.reset_index()
    churn_reasons_df.columns = ['Churn_Reason', 'Count']

    fig = px.bar(churn_reasons_df, x='Churn_Reason', y='Count', 
                 title='Primary Reasons for Customer Churn', 
                 labels={'Count': 'Number of Churns'}, 
                 color='Count')
    st.plotly_chart(fig)

def show_detailed_summary_dashboard(clean_df):
    st.sidebar.title(" Detailed Summary")
    
    # Sidebar navigation for detailed summary
    summary_option = st.sidebar.selectbox(
        "Select Summary Category",
        ["Overall Insights", "Demographic Analysis", "Geographic Breakdown", 
         "Account Information", "Service Usage"]
    )
    
    st.title(f"Detailed Summary: {summary_option}")
    
    if summary_option == "Overall Insights":
        st.header("Business Overview")
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            st.metric("Total Customers", len(clean_df))
        with col2:
            churn_rate = (clean_df['Customer_Status'].value_counts(normalize=True).get('Churned', 0) * 100).round(2)
            st.metric("Churn Rate", f"{churn_rate}%")
        with col3:
            avg_tenure = clean_df['Tenure_in_Months'].mean().round(2)
            st.metric("Avg. Tenure (months)", avg_tenure)
        with col4:
            avg_revenue = clean_df['Total_Revenue'].mean().round(2)
            st.metric("Avg. Revenue", f"${avg_revenue}")

    elif summary_option == "Demographic Analysis":
        demographic.total_churn_by_gender(clean_df)
        demographic.total_customers_and_churn_rate_by_tenure_gender(clean_df)

    elif summary_option == "Geographic Breakdown":
        geographic.churn_rate_by_state(clean_df)

    elif summary_option == "Account Information":
        account_info.churn_rate_by_contact(clean_df)
        account_info.churn_rate_by_payment_method(clean_df)

    elif summary_option == "Service Usage":
        service_used.churn_by_services(clean_df)
        service_used.churn_rate_by_internet_type(clean_df)

def show_predictions_dashboard(clean_df):
    st.sidebar.title("Prediction Visuals")
    
    # Sidebar navigation for prediction visuals
    prediction_options = st.sidebar.selectbox(
        "Select Prediction Category",
        ["Overall report","Demographic Analysis", "Geographic Breakdown", 
         "Financial Risk Analysis", "Service Usage", "Advanced Predictive"]
    )

    if prediction_options == "Demographic Analysis":
        prediction_visual.demographic_analysis(clean_df)
    
    elif prediction_options == "Geographic Breakdown":

        prediction_visual.geographical_analysis(clean_df)
    
    elif prediction_options == "Financial Risk Analysis":
        prediction_visual.financial_risk_analysis(clean_df)

    elif prediction_options == "Service Usage":
        prediction_visual.service_usage_analysis(clean_df)

    elif prediction_options == "Advanced Predictive":
        prediction_visual.predictive_insights(clean_df)

    elif prediction_options == "Overall report":
        # elif prediction_options == "Overall Report":
        st.header("Comprehensive Churn Prediction Report")
        
        # Generate the report
        try:
            # Create two columns for better layout
            col1, col2 = st.columns([1, 3])
            
            with col1:
                # Key metrics summary
                churn_rate = (clean_df['Customer_Status'].value_counts(normalize=True).get('Churned', 0) * 100).round(2)
                st.metric("Total Customers", len(clean_df))
                st.metric("Churn Rate", f"{churn_rate}%")
                st.metric("Avg. Tenure (months)", clean_df['Tenure_in_Months'].mean().round(2))
            
            with col2:
                # Detailed report
                report = prediction_visual.generate_report(clean_df)
                
                # Use st.code for better formatting
                st.code(report, language="markdown")
                
                # Optional: Download report button
                st.download_button(
                    label="Download Full Report",
                    data=report,
                    file_name="churn_prediction_report.txt",
                    mime="text/plain"
                )
        
        except Exception as e:
            st.error(f"Error generating report: {e}")
            st.exception(e)
        # prediction_visual.generate_report(clean_df)

if __name__ == "__main__":
    main()
