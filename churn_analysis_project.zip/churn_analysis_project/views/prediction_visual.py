import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
import streamlit as st
from algorithems import random_forest
from services import clean_data

# Function to load data with error handling
def load_data(file_path):
    try:
        return pd.read_csv(file_path)
    except FileNotFoundError:
        st.error(f"File not found: {file_path}")
        return None

# Demographic Analysis
def demographic_analysis(predictions_df):
    if 'Age' not in predictions_df.columns or 'Gender' not in predictions_df.columns:
        st.error("Required columns are missing from the DataFrame.")
        return {}

    plt.figure(figsize=(12, 6))
    
    # Age distribution
    plt.subplot(1, 2, 1)
    sns.histplot(predictions_df['Age'], kde=True)
    plt.title('Age Distribution of Potential Churners')
    plt.xlabel('Age')
    plt.ylabel('Count')
    
    # Gender distribution
    plt.subplot(1, 2, 2)
    predictions_df['Gender'].value_counts().plot(kind='pie', autopct='%1.1f%%')
    plt.title('Gender Distribution of Potential Churners')
    plt.tight_layout()
    
    st.pyplot(plt)  # Display the figure in Streamlit
    plt.clf()  # Clear the figure for the next plot
    
    result = {
        'age_stats': {
            'mean_age': predictions_df['Age'].mean(),
            'median_age': predictions_df['Age'].median(),
            'age_range': f"{predictions_df['Age'].min()} - {predictions_df['Age'].max()}"
        },
        'gender_distribution': predictions_df['Gender'].value_counts().to_dict()
    }
    
    return result

# Geographical Analysis
def geographical_analysis(predictions_df):
    if 'State' not in predictions_df.columns:
        st.error("State column is missing from the DataFrame.")
        return {}

    state_counts = predictions_df['State'].value_counts()
    plt.figure(figsize=(15, 6))
    state_counts.plot(kind='bar')
    plt.title('Potential Churners by State')
    plt.xlabel('State')
    plt.ylabel('Number of Potential Churners')
    plt.xticks(rotation=45, ha='right')
    plt.tight_layout()
    
    st.pyplot(plt)  # Display the figure in Streamlit
    plt.clf()  # Clear the figure for the next plot
    
    return {
        'top_5_states': state_counts.head().to_dict(),
        'total_states': len(state_counts)
    }

# Financial Risk Analysis
def financial_risk_analysis(predictions_df):
    financial_columns = [
        'Monthly_Charge', 'Total_Charges', 'Total_Refunds', 
        'Total_Extra_Data_Charges', 'Total_Long_Distance_Charges'
    ]
    
    for col in financial_columns:
        if col not in predictions_df.columns:
            st.error(f"{col} column is missing from the DataFrame.")
            return {}

    plt.figure(figsize=(10, 8))
    correlation_matrix = predictions_df[financial_columns].corr()
    sns.heatmap(correlation_matrix, annot=True, cmap='coolwarm', center=0)
    plt.title('Financial Metrics Correlation for Potential Churners')
    plt.tight_layout()
    
    st.pyplot(plt)  # Display the figure in Streamlit
    plt.clf()  # Clear the figure for the next plot
    
    return {
        'average_monthly_charge': predictions_df['Monthly_Charge'].mean(),
        'total_financial_risk': predictions_df['Total_Charges'].sum(),
        'financial_metrics': predictions_df[financial_columns].describe().to_dict()
    }

# Service Usage Analysis
def service_usage_analysis(predictions_df):
    service_columns = [
        'Phone_Service', 'Multiple_Lines', 'Internet_Service', 
        'Internet_Type', 'Online_Security', 'Online_Backup',
        'Streaming_TV', 'Streaming_Movies'
    ]
    
    service_usage = {}
    plt.figure(figsize=(15, 8))
    for i, column in enumerate(service_columns, 1):
        if column not in predictions_df.columns:
            st.error(f"{column} column is missing from the DataFrame.")
            continue
        
        plt.subplot(2, 4, i)
        predictions_df[column].value_counts().plot(kind='pie', autopct='%1.1f%%')
        plt.title(f'{column} Usage')
  
        service_usage[column] = predictions_df[column].value_counts().to_dict()
    
    plt.tight_layout()
    st.pyplot(plt)  # Display the figure in Streamlit
    plt.clf()  # Clear the figure for the next plot
    
    return service_usage

# Predictive Insights
def predictive_insights(predictions_df):
    numeric_columns = predictions_df.select_dtypes(include=['int64', 'float64']).columns
    X = predictions_df[numeric_columns]

    scaler = StandardScaler()
    # Scale the data
    X_scaled = scaler.fit_transform(X)

    # PCA for dimensionality reduction
    pca = PCA(n_components=2)
    X_pca = pca.fit_transform(X_scaled)

    plt.figure(figsize=(10, 8))
    plt.scatter(X_pca[:, 0], X_pca[:, 1])
    plt.title('PCA Visualization of Potential Churners')
    plt.xlabel('First Principal Component')
    plt.ylabel('Second Principal Component')
    st.pyplot(plt)  # Display the figure in Streamlit
    plt.clf()  # Clear the figure for the next plot
    
    st.write( {
        'explained_variance_ratio': pca.explained_variance_ratio_.tolist(),
        'total_variance_explained': sum(pca.explained_variance_ratio_)
    })

    return {
        'explained_variance_ratio': pca.explained_variance_ratio_.tolist(),
        'total_variance_explained': sum(pca.explained_variance_ratio_)
    }

def analysis_results(predictions_df):
    results = {}
    results['demographic'] = demographic_analysis(predictions_df)
    results['geographical'] = geographical_analysis(predictions_df)
    results['financial'] = financial_risk_analysis(predictions_df)
    results['service_usage'] = service_usage_analysis(predictions_df)
    results['predictive_insights'] = predictive_insights(predictions_df)
    return results

def generate_report(predictions_df):
    # If predictions_df is a DataFrame, we'll directly extract insights from it
    report = "Churn Prediction Comprehensive Analysis\n"
    report += "=======================================\n\n"
    
    # 1. Demographic Insights
    report += "1. Demographic Insights\n"
    try:
        # Attempt to calculate demographic stats directly from the DataFrame
        report += f"   - Average Age: {predictions_df['Age'].mean():.2f}\n"
        
        # Gender distribution
        gender_dist = predictions_df['Gender'].value_counts(normalize=True)
        report += "   - Gender Distribution:\n"
        for gender, percentage in gender_dist.items():
            report += f"     * {gender}: {percentage:.1%}\n"
    except Exception as e:
        report += f"   - Demographic analysis unavailable: {e}\n"
    
    # 2. Geographical Risk
    report += "\n2. Geographical Risk\n"
    try:
        state_counts = predictions_df['State'].value_counts()
        top_5_states = state_counts.head()
        report += "   - Top 5 High-Risk States:\n"
        for state, count in top_5_states.items():
            report += f"     * {state}: {count} potential churners\n"
        report += f"   - Total States Analyzed: {len(state_counts)}\n"
    except Exception as e:
        report += f"   - Geographical analysis unavailable: {e}\n"
    
    # 3. Financial Risk
    report += "\n3. Financial Risk\n"
    try:
        financial_columns = ['Monthly_Charge', 'Total_Charges', 'Total_Refunds']
        report += f"   - Average Monthly Charge: ${predictions_df['Monthly_Charge'].mean():.2f}\n"
        report += f"   - Total Financial Risk: ${predictions_df['Total_Charges'].sum():.2f}\n"
        
        # Additional financial metrics
        report += "   - Financial Metrics:\n"
        for col in financial_columns:
            report += f"     * {col.replace('_', ' ')}: ${predictions_df[col].mean():.2f}\n"
    except Exception as e:
        report += f"   - Financial analysis unavailable: {e}\n"
    
    # 4. Service Usage
    report += "\n4. Service Usage\n"
    try:
        service_columns = [
            'Phone_Service', 'Multiple_Lines', 'Internet_Service', 
            'Internet_Type', 'Online_Security', 'Online_Backup',
            'Streaming_TV', 'Streaming_Movies'
        ]
        
        for column in service_columns:
            if column in predictions_df.columns:
                service_dist = predictions_df[column].value_counts(normalize=True)
                report += f"   - {column.replace('_', ' ')} Distribution:\n"
                for service, percentage in service_dist.items():
                    report += f"     * {service}: {percentage:.1%}\n"
    except Exception as e:
        report += f"   - Service usage analysis unavailable: {e}\n"

    # 5. Predictive Insights
    report += "\n5. Predictive Insights\n"
    try:
        # Calculate churn rate based on Customer_Status
        if 'Customer_Status' in predictions_df.columns:
            churn_rate = (predictions_df['Customer_Status'] == 'Churned').mean()
            report += f"   - Actual Churn Rate: {churn_rate:.1%}\n"
        
        # Additional predictive metrics
        if 'Churn_Probability' in predictions_df.columns:
            # Average churn probability
            avg_churn_prob = predictions_df['Churn_Probability'].mean()
            report += f"   - Average Churn Probability: {avg_churn_prob:.1%}\n"
            
            # High-risk customer segment
            high_risk_threshold = 0.7  # 70% probability of churning
            high_risk_customers = predictions_df[predictions_df['Churn_Probability'] > high_risk_threshold]
            high_risk_percentage = len(high_risk_customers) / len(predictions_df)
            report += f"   - High-Risk Customer Segment (>{high_risk_threshold*100:.0f}% churn probability): {high_risk_percentage:.1%}\n"
        
        # Predictive model performance (if available)
        if 'Predicted_Churn' in predictions_df.columns and 'Customer_Status' in predictions_df.columns:
            # Calculate confusion matrix-like metrics
            true_positives = ((predictions_df['Predicted_Churn'] == 1) & (predictions_df['Customer_Status'] == 'Churned')).sum()
            false_positives = ((predictions_df['Predicted_Churn'] == 1) & (predictions_df['Customer_Status'] == 'Active')).sum()
            false_negatives = ((predictions_df['Predicted_Churn'] == 0) & (predictions_df['Customer_Status'] == 'Churned')).sum()
            
            precision = true_positives / (true_positives + false_positives) if (true_positives + false_positives) > 0 else 0
            recall = true_positives / (true_positives + false_negatives) if (true_positives + false_negatives) > 0 else 0
            
            report += f"   - Model Precision: {precision:.1%}\n"
            report += f"   - Model Recall: {recall:.1%}\n"
    
    except Exception as e:
        report += f"   - Predictive insights unavailable: {str(e)}\n"
    
    return report
