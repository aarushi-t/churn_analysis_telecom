import streamlit as st
import plotly.express as px
import pandas as pd
import plotly.express as px
import pandas as pd
from services import clean_data

# Load and clean the data
df = clean_data.data_cleaning()

def churn_rate_by_payment_method(df):
    # Calculate churn counts and total counts
    churn_counts = df[df['Customer_Status'] == 'Churned'].groupby('Payment_Method').size()
    total_counts = df.groupby('Payment_Method').size()
    
    # Calculate churn rate
    churn_rate = (churn_counts / total_counts).fillna(0).reset_index(name='Churn_Rate')
    churn_rate.columns = ['Payment_Method', 'Churn_Rate']
    
    # Plotting
    fig = px.bar(churn_rate, 
                  x='Payment_Method', 
                  y='Churn_Rate', 
                  title='Churn Rate by Payment Method',
                  labels={'Churn_Rate': 'Churn Rate', 'Payment_Method': 'Payment Method'},
                  color='Churn_Rate',
                  color_continuous_scale=px.colors.sequential.Viridis)
    
    fig.update_layout(xaxis_title='Payment_Method', yaxis_title='Churn_Rate')
    st.plotly_chart(fig)
    
    return churn_rate

def churn_rate_by_contact(df):
    # Calculate total counts
    total_counts = df['Customer_Status'].value_counts().reset_index()
    total_counts.columns = ['Status', 'Counts']

    # Initialize churn_counts
    churn_counts = 0

    # Check if total_counts DataFrame is empty
    if not total_counts.empty:
        # Check if 'Inactive' status exists
        if 'Inactive' in total_counts['Status'].values:
            churn_counts = total_counts[total_counts['Status'] == 'Inactive']['Counts'].values[0]
        else:
            print("No churned customers found.")
    else:
        print("Total counts DataFrame is empty.")

    # Print the counts
    print("Total Counts:\n", total_counts)
    print("\nChurn Counts:", churn_counts)

    # Plotting the results
    fig = px.bar(
        total_counts,
        x='Status',
        y='Counts',
        title='Customer Status Counts',
        color='Counts',
        color_continuous_scale=px.colors.sequential.Viridis
    )
    fig.update_layout(xaxis_title='Status', yaxis_title='Counts')
    st.plotly_chart(fig)

def churn_rate_and_total_churn_by_age_group(df, bins):
    """Calculate and plot churn rate and total churn by age group."""
    
    # Check if necessary columns exist
    if 'Age' not in df.columns or 'Customer_Status' not in df.columns:
        raise ValueError("DataFrame must contain 'Age' and 'Customer_Status' columns.")
    
    # Create age groups
    df['Age_Group'] = pd.cut(df['Age'], bins=bins)
    
    # Calculate churn counts and total counts
    churn_counts = df[df['Customer_Status'] == 'Churned'].groupby('Age_Group').size()
    total_counts = df.groupby('Age_Group').size()
    
    # Calculate churn rate
    churn_rate = churn_counts / total_counts
    
    # Create DataFrame for plotting
    churn_data = pd.DataFrame({'Total Churn': churn_counts, 'Churn Rate': churn_rate}).fillna(0).reset_index()
    
    # Ensure churn_data is not empty
    if churn_data.empty:
        print("No data available for the specified age groups.")
        return churn_data
    
    # Plotting Total Churn
    fig1 = px.bar(churn_data, 
                  x='Age_Group', 
                  y='Total Churn', 
                  title='Total Churn by Age Group',
                  labels={'Total Churn': 'Total Churned Customers', 'Age_Group': 'Age Group'},
                  color='Total Churn',
                  color_continuous_scale=px.colors.sequential.Viridis)
    
    fig1.update_layout(xaxis_title='Age Group', yaxis_title='Total Churned Customers')
    st.plotly_chart(fig1)
    
    # Plotting Churn Rate
    fig2 = px.bar(churn_data, 
                  x='Age_Group', 
                  y='Churn Rate', 
                  title='Churn Rate by Age Group',
                  labels={'Churn Rate': 'Churn Rate', 'Age_Group': 'Age Group'},
                  color='Churn Rate',
                  color_continuous_scale=px.colors.sequential.Viridis)
    
    fig2.update_layout(xaxis_title='Age Group', yaxis_title='Churn Rate')
    st.plotly_chart(fig2)
    
    return churn_data
