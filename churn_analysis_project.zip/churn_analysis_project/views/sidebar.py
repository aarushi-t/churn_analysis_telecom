import streamlit as st
import pandas as pd
from datetime import datetime
from typing import Optional, Dict, Any

def setup_sidebar_style():
    """Setup custom styling for the sidebar"""
    st.markdown(
        """
        <style>
        .sidebar-content {
            padding: 1rem;
        }
        .user-info {
            padding: 1rem;
            margin-bottom: 1rem;
            border-radius: 0.5rem;
            background: #f0f2f6;
        }
        </style>
        """,
        unsafe_allow_html=True
    )

def show_user_info(session_manager):
    """Display user information in the sidebar"""
    session_info = session_manager.get_session_info()
    if session_info:
        st.sidebar.markdown("### 👤 User Profile")
        st.sidebar.markdown(f"**User :** {session_info['user_name']}")
        st.sidebar.markdown(f"**Last Activity:** {session_info['last_activity'].strftime('%H:%M:%S')}")
        
        # Show session expiry countdown
        time_left = session_info['session_expiry'] - datetime.now()
        hours_left = time_left.seconds // 3600
        minutes_left = (time_left.seconds % 3600) // 60
        st.sidebar.markdown(f"**Session expires in:** {hours_left}h {minutes_left}m")

def render_navigation(session_manager) -> Dict[str, Any]:
    """
    Render the sidebar navigation and return selected options
    
    Args:
        session_manager: Instance of SessionManager for tracking user session
        
    Returns:
        dict: Selected options and filters
    """
    st.sidebar.title("📊 Analytics Dashboard")
    show_user_info(session_manager)
    
    # Main Navigation
    st.sidebar.markdown(" 🔍 Analysis Options")
    
    main_options = {
        "dashboard": "📈 Dashboard Overview",
        "customer_analysis": " Customer Analysis",
        "churn_analysis": "📉 Churn Analysis",
        "revenue_analysis": "💰 Revenue Analysis",
        "predictions": "🔮 Churn Predictions"
    }
    
    selected_main = st.sidebar.selectbox(
        "Select Analysis Type",
        options=list(main_options.keys()),
        format_func=lambda x: main_options[x]
    )
    
    # Filters Section
    st.sidebar.markdown("### 🔧 Filters")
    
    # Date Range Filter
    date_filter = st.sidebar.date_input(
        "Date Range",
        value=[datetime.now().date(), datetime.now().date()],
        key="date_filter"
    )
    
    # Customer Segment Filter
    segment_filter = st.sidebar.multiselect(
        "Customer Segments",
        options=["New", "Regular", "Premium", "VIP"],
        default=["Regular", "Premium"]
    )
    
    # Contract Type Filter
    contract_filter = st.sidebar.multiselect(
        "Contract Types",
        options=["Month-to-Month", "One Year", "Two Year"],
        default=["Month-to-Month", "One Year", "Two Year"]
    )
    
    # Additional Options based on main selection
    sub_options = get_sub_options(selected_main)
    selected_sub = None
    if sub_options:
        selected_sub = st.sidebar.selectbox(
            "Select Detail View",
            options=list(sub_options.keys()),
            format_func=lambda x: sub_options[x]
        )
    
    # Export Options
    st.sidebar.markdown("### 📤 Export Options")
    if st.sidebar.button("Export Analysis Report"):
        session_manager.track_activity(
            'export_report',
            {'type': 'analysis', 'format': 'pdf'}
        )
        st.sidebar.success("Report queued for export!")
    
    # Logout Option
    st.sidebar.markdown("### 🚪 Session")
    if st.sidebar.button("Logout"):
        session_manager.end_session()
        st.experimental_rerun()
    
    # Return selected options and filters
    return {
        "main_option": selected_main,
        "sub_option": selected_sub,
        "filters": {
            "date_range": date_filter,
            "segments": segment_filter,
            "contract_types": contract_filter
        }
    }

def get_sub_options(main_option: str) -> Dict[str, str]:
    """
    Get sub-options based on main selection
    
    Args:
        main_option (str): Selected main option
        
    Returns:
        dict: Sub-options mapping
    """
    sub_options = {
        "dashboard": {
            "overview": "Overview",
            "metrics": "Key Metrics",
            "trends": "Trends"
        },
               "customer_analysis": {
            "segments": "Customer Segments",
            "demographics": "Demographics",
            "behavior": "Customer Behavior",
            "lifetime": "Customer Lifetime Value"
        },
        "churn_analysis": {
            "rates": "Churn Rates",
            "reasons": "Churn Reasons",
            "risk": "Risk Analysis",
            "prevention": "Prevention Strategies"
        },
        "revenue_analysis": {
            "overview": "Revenue Overview",
            "impact": "Churn Impact",
            "forecasting": "Revenue Forecasting",
            "optimization": "Revenue Optimization"
        },
        "predictions": {
            "risk_scores": "Risk Scores",
            "likely_churners": "Likely Churners",
            "recommendations": "Retention Recommendations",
            "what_if": "What-If Analysis"
        }
    }
    
    return sub_options.get(main_option, {})

def apply_filters(df: pd.DataFrame, filters: Dict[str, Any]) -> pd.DataFrame:
    """
    Apply selected filters to the dataset
    
    Args:
        df (pd.DataFrame): Analysis dataset
        filters (dict): Selected filter options
        
    Returns:
        pd.DataFrame: Filtered dataset
    """
    filtered_df = df.copy()
    
    # Apply date filter if available
    if "date_range" in filters and len(filters["date_range"]) == 2:
        start_date, end_date = filters["date_range"]
        filtered_df = filtered_df[
            (filtered_df["date"] >= start_date) &
            (filtered_df["date"] <= end_date)
        ]
    
    # Apply segment filter
    if "segments" in filters and filters["segments"]:
        filtered_df = filtered_df[
            filtered_df["customer_segment"].isin(filters["segments"])
        ]
    
    # Apply contract type filter
    if "contract_types" in filters and filters["contract_types"]:
        filtered_df = filtered_df[
            filtered_df["contract_type"].isin(filters["contract_types"])
        ]
    
    return filtered_df
