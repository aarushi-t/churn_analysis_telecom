import streamlit as st
import plotly.express as px
import pandas as pd
from services import clean_data

# Load and clean the data
df = clean_data.data_cleaning()

def total_churn_by_churn_category(df):
    # Calculate total churn by churn category
    churn_counts = df[df['Customer_Status'] == 'Churned'].groupby('Churn_Reason').size().reset_index(name='Total_Churn')
    
    # Plotting
    fig = px.bar(churn_counts, 
                 x='Churn_Reason', 
                 y='Total_Churn', 
                 title='Total churn by Churn Category',
                 labels={'Total_Churn': 'Number of Churned Customers', 'Churn_Reason': 'Churn_Reason'},
                 color='Total_Churn',
                 color_continuous_scale=px.colors.sequential.Viridis)
    
    # Update layout for better readability
    fig.update_layout(xaxis_title='Churn_Reason', yaxis_title='Number of Churned Customers', xaxis_tickangle=-45)
    
    st.plotly_chart(fig)
    
    return churn_counts
