import streamlit as st
import plotly.express as px
import pandas as pd
from services import clean_data

# Load and clean the data
df = clean_data.data_cleaning()

def churn_rate_by_internet_type(df):
    # Calculate churn counts and total counts
    churn_counts = df[df['Customer_Status'] == 'Churned'].groupby('Internet_Service').size()
    total_counts = df.groupby('Internet_Service').size()
    
    # Calculate churn rate
    churn_rate = churn_counts / total_counts
    churn_rate = churn_rate.fillna(0).reset_index(name='Churn_Rate')
    churn_rate.columns = ['Internet_Service', 'Churn_Rate']

    # Plotting
    fig = px.bar(churn_rate, 
                 x='Internet_Service', 
                 y='Churn_Rate', 
                 title='Churn Rate by Internet Type',
                 labels={'Churn_Rate': 'Churn Rate', 'Internet_Service': 'Internet Service'},
                 color='Churn_Rate',
                 color_continuous_scale=px.colors.sequential.Viridis)
    st.plotly_chart(fig)

def churn_by_services(df):
    # Calculate churn counts by services
    churn_counts = df[df['Customer_Status'] == 'Churned'].groupby('Multiple_Lines').size().reset_index(name='Churn_Count')
    churn_counts.columns = ['Multiple_Lines', 'Churn_Count']

    # Plotting
    fig = px.bar(churn_counts, 
                 x='Multiple_Lines', 
                 y='Churn_Count', 
                 title='Churn by Services',
                 labels={'Churn_Count': 'Number of Churned Customers', 'Multiple_Lines': 'Multiple Services'},
                 color='Churn_Count',
                 color_continuous_scale=px.colors.sequential.Viridis)
    st.plotly_chart(fig)
    
    return churn_counts
