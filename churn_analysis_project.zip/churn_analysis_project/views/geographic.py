import streamlit as st
import plotly.express as px
import pandas as pd
from services import clean_data

# Load and clean the data
df = clean_data.data_cleaning()

def churn_rate_by_state(df, top_n=10):
    # Calculate churn counts and total counts
    churn_counts = df[df['Customer_Status'] == 'Churned'].groupby('State').size()
    total_counts = df.groupby('State').size()
    
    # Calculate churn rate
    churn_rate = (churn_counts / total_counts).fillna(0).reset_index(name='Churn_Rate')
    churn_rate.columns = ['State', 'Churn_Rate']
    
    # Get top N states by churn rate
    top_churn_rate = churn_rate.nlargest(top_n, 'Churn_Rate')
    
    # Plotting
    fig = px.bar(top_churn_rate, 
                 x='State', 
                 y='Churn_Rate', 
                 title=f'Top {top_n} States by Churn_Rate',
                 labels={'Churn_Rate': 'Churn_Rate', 'State': 'State'},
                 color='Churn_Rate',
                 color_continuous_scale=px.colors.sequential.Viridis)
    st.plotly_chart(fig)
    
    return top_churn_rate
