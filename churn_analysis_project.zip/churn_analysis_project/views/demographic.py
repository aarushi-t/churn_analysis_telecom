import streamlit as st
import plotly.express as px
import pandas as pd
from services import clean_data

# Load and clean the data
df = clean_data.data_cleaning()

def total_churn_by_gender(df):
    # Calculate total churn by gender
    churn_counts = df[df['Customer_Status'] == 'Churned'].groupby('Gender').size().reset_index(name='Total_Churn')
    
    # Plotting
    fig = px.pie(churn_counts, 
                 names='Gender', 
                 values='Total_Churn', 
                 title='Total Churn by Gender',
                 color='Gender',
                 color_discrete_map={'Male': 'blue', 'Female': 'red'})
    st.plotly_chart(fig)
    return churn_counts

def total_customers_and_churn_rate_by_tenure_gender(df):
    # Group by Tenure and Gender and calculate total customers and churned customers
    grouped = df.groupby(['Tenure_in_Months', 'Gender']).agg(
        total_customers=('Customer_ID', 'size'),
        churned_customers=('Customer_Status', lambda x: (x == 'Churned').sum())
    )
    grouped['churn_rate'] = grouped['churned_customers'] / grouped['total_customers']
    
    # Reset index for plotting
    grouped = grouped.reset_index()

    # Plotting total customers
    fig1 = px.bar(grouped, 
                  x='Tenure_in_Months', 
                  y='total_customers', 
                  color='Gender', 
                  title='Total Customers by Tenure_in_Months and Gender',
                  labels={'total_customers': 'Total Customers', 'Tenure_in_Months': 'Tenure_in_Months'},
                  barmode='group')
    st.plotly_chart(fig1)

    # Plotting churn rate
    fig2 = px.bar(grouped, 
                  x='Tenure_in_Months', 
                  y='churn_rate', 
                  color='Gender', 
                  title='Churn Rate by Tenure_in_Months and Gender',
                  labels={'churn_rate': 'Churn Rate', 'Tenure_in_Months': 'Tenure_in_Months'},
                  barmode='group')
    st.plotly_chart(fig2)
    
    return grouped
