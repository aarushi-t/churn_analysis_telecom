import pymysql
import streamlit as st
from validations import user_validation
from services import db_connection
from models import user_details
from services import credentials_check
from services import session


def signup():
    st.title("Welcome to the Signup Page! ")

    with st.form("signup_form"):
        # Name input
        name = st.text_input("Enter your name")
        
        # Email input
        email = st.text_input("Enter your email (must end with @gmail.com)")
        
        # Contact input
        contact = st.text_input("Enter your contact number")
        
        # Password input
        password = st.text_input("Enter your password (minimum 6 characters)", type="password")
        
        # Submit button
        submitted = st.form_submit_button("Sign Up")
        
        if submitted:
            # Validate name
            if not user_validation.valid_name(name):
                st.error("Please enter a valid name")
                return
            
            # Validate email
            if not user_validation.is_valid_email(email):
                st.error("Invalid email format. Please enter a valid gmail address.")
                return
            
            # Validate contact
            contact_validation_result = user_validation.wrong_contact(contact)
            if contact_validation_result is not True:
                # st.error(contact_validation_result)
                st.error("Please enter a valid contact number.")
                return
            
            # Check if account exists
            if user_details.account_check(email, contact):
                st.error("An account with this email or contact number already exists. Please try again.")
                return
            
            # Validate password
            if not user_validation.password_check(password):
                st.error("Password must be at least 6 characters long.")
                return
            
            # If all validations pass, create account
            try:
                user_details.open_account(name, password, email, contact)
                st.success("Signup successful!, You can now log-in")
                
                
                # Display user details in an expandable section
                with st.expander("View Account Details"):
                    st.write(f"**Name:** {name}")
                    st.write(f"**Email:** {email}")
                    st.write(f"**Contact Number:** {contact}")

                
                # Clear the form (optional)
                # st.session_state.clear()
                
            except Exception as e:
                st.error(f"An error occurred during signup: {str(e)}")
                       
def login():

    login_input = st.text_input("Email or Contact")
    login_password = st.text_input("Password", type="password")
    
    if st.button("Login"):
        if login_input and login_password:       
            if credentials_check.check_user_email(login_input):
                if credentials_check.check_password(login_password, login_input):
                    st.session_state.logged_in = True
                    user_data = {"user_name": "Test User", "user_id": 1}
                    session.start_session(user_data)
                    st.session_state.page = "main_dashboard"                 
                else:
                    st.error("Invalid Password")
            else:
                st.error("Invalid Email or Contact")
        else:
            st.error("Please fill in all fields")

        con, cursor = db_connection.connect_to_database()

def logout():
    # Clear session state to log out the user
    st.session_state.clear()
    st.success("You have been logged out successfully!")
