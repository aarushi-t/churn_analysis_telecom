import streamlit as st
from datetime import datetime, timedelta
# Constants
SESSION_DURATION = timedelta(hours=24)  # Set session timeout to 24 hours

def init_session_state():
    """Initialize session state variables if they don't exist"""
    if 'logged_in' not in st.session_state:
        st.session_state.logged_in = False
    if 'user_info' not in st.session_state:
        st.session_state.user_info = None
    if 'login_time' not in st.session_state:
        st.session_state.login_time = None
    
    return st.session_state

def start_session(user_data: dict):
    """Start a new session for a user
    
    Args:
        user_data (dict): Dictionary containing user information
                        Expected keys: 'user_name', 'user_id'
    """
    st.session_state.logged_in = True
    st.session_state.user_info = user_data
    st.session_state.login_time = datetime.now()

def end_session():
    """End the current session"""
    st.session_state.logged_in = False
    st.session_state.user_info = None
    st.session_state.login_time = None

def check_session_validity() -> bool:
    """Check if the current session is valid
    
    Returns:
        bool: True if session is valid, False otherwise
    """
    if not st.session_state.logged_in:
        return False
        
    if st.session_state.login_time is None:
        return False
        
    current_time = datetime.now()
    session_age = current_time - st.session_state.login_time
    
    return session_age <= SESSION_DURATION

def get_session_info() -> dict:
    """Get information about the current session
    
    Returns:
        dict: Session information including user details and session duration
    """
    if not st.session_state.logged_in:
        return {}
        
    session_info = {
        'user_name': st.session_state.user_info.get('user_name', 'Unknown'),
        'user_id': st.session_state.user_info.get('user_id', None),
        'login_time': st.session_state.login_time,
        'session_expires': st.session_state.login_time + SESSION_DURATION if st.session_state.login_time else None
    }
    return session_info
