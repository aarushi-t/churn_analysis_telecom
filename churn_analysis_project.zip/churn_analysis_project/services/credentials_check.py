from models import user_details

def check_user_email(login_input):
    if "@" in login_input:
        if  login_input in user_details.get_user_by_email(login_input):
            return True
        else:
            return False

    else:
        if int(login_input) in user_details.get_user_by_contact(login_input):
            return True
        else:
            return False

def check_password(login_password,login_input):
    if "@" in login_input:
        if login_password in user_details.get_password_email(login_input):
             return True
        else:
             return False

    else:
        if login_password in user_details.get_password_contact(int(login_input)):
             return True
        else:
             return False
            