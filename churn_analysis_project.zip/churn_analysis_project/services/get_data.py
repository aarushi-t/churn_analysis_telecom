import pandas as pd
import os

def read_data():

        # Attempt to read the CSV file
        try:
            # df = pd.read_csv(r'C:\Users\AARUSHI\Desktop\churn_analysis\Customer_Data.csv')
            df = pd.read_csv(r'C:\Users\AARUSHI\Desktop\final projects\churn_analysis_project\Customer_Data.csv')
                       
            return df
        except FileNotFoundError as e:
            print("Error: File not found.")
            print(e)

