import pymysql

def connect_to_database():

    """Establish a connection to the database and return the connection and cursor."""

    con = pymysql.connect(host='localhost', user='root', password='root', db='db_churn')
    cursor = con.cursor()
    return con, cursor

def close_connection(con):

    """Close the database connection."""
    
    if con:
        con.close()
