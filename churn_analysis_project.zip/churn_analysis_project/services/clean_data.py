from services import get_data

def data_cleaning():
    call_data = get_data.read_data()
    clean_call_data= call_data.dropna(subset=['Customer_ID'])
    clean_call_data["Value_Deal"] = clean_call_data["Value_Deal"].fillna('None')
    clean_call_data['Internet_Type'] = clean_call_data["Internet_Type"].fillna('None')

    clean_call_data["Multiple_Lines"] = clean_call_data["Multiple_Lines"].fillna('No')
    clean_call_data["Churn_Category"] = clean_call_data["Churn_Category"].fillna('Others')
    clean_call_data["Churn_Reason"] = clean_call_data["Churn_Reason"].fillna('Others')

    # Select the specified columns and fill missing values
    clean_call_data[call_data.columns[12:20]] = clean_call_data[clean_call_data.columns[12:20]].fillna('No')

    #Data Type Conversion
    ''' Convert 'Age', 'Number_of_Referrals', 'Tenure_in_Months' to integers'''

    clean_call_data['Age'] = clean_call_data['Age'].astype(int)
    clean_call_data['Number_of_Referrals'] = clean_call_data['Number_of_Referrals'].astype(int)
    clean_call_data['Tenure_in_Months'] = clean_call_data['Tenure_in_Months'].astype(int)

    ''' Convert 'Monthly_Charge', 'Total_Charges', 'Total_Refunds', etc. to floats'''

    clean_call_data['Monthly_Charge'] = clean_call_data['Monthly_Charge'].astype(float)
    clean_call_data['Total_Charges'] = clean_call_data['Total_Charges'].astype(float)
    clean_call_data['Total_Refunds'] = clean_call_data['Total_Refunds'].astype(float)
    clean_call_data['Total_Extra_Data_Charges'] = clean_call_data['Total_Extra_Data_Charges'].astype(float)
    clean_call_data['Total_Long_Distance_Charges'] = clean_call_data['Total_Long_Distance_Charges'].astype(float)
    clean_call_data['Total_Revenue'] = clean_call_data['Total_Revenue'].astype(float)
    # # Save the cleaned data 
    clean_call_data.to_csv('cleaned_data.csv', index = False)
    return clean_call_data
