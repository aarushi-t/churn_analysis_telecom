import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.preprocessing import LabelEncoder
from services import clean_data
import logging

df = clean_data.data_cleaning()

# Separate data for prediction (customers who have joined)
df_to_predict = df[df['Customer_Status'].isin(['Joined'])]

# # Train the model
def train_churn_model(df):
    """
    Train a Random Forest model for churn prediction
    
    Parameters:
    df (pandas.DataFrame): Input dataframe with customer data
    
    Returns:
    tuple: Trained model, label encoders, and feature columns
    """
    # Filter data for Stayed and Churned customers
    df_1 = df[df['Customer_Status'].isin(['Stayed', 'Churned'])]

    # Drop columns that won't be used for prediction
    data = df_1.drop(['Customer_ID', 'Churn_Category', 'Churn_Reason'], axis=1)

    # List of columns to be label encoded
    columns_to_encode = [
        'Gender', 'Married', 'State', 'Value_Deal', 'Phone_Service', 'Multiple_Lines',
        'Internet_Service', 'Internet_Type', 'Online_Security', 'Online_Backup',
        'Device_Protection_Plan', 'Premium_Support', 'Streaming_TV', 'Streaming_Movies',
        'Streaming_Music', 'Unlimited_Data', 'Contract', 'Paperless_Billing',
        'Payment_Method'
    ]

    # Encode categorical variables except the target variable
    label_encoders = {}
    for column in columns_to_encode:
        label_encoders[column] = LabelEncoder()
        data[column] = label_encoders[column].fit_transform(data[column])

    # Manually encode the target variable 'Customer_Status'
    data['Customer_Status'] = data['Customer_Status'].map({'Stayed': 0, 'Churned': 1})

    # Drop rows with NaN values
    data.dropna(inplace=True)

    # Split data into features and target
    X = data.drop('Customer_Status', axis=1)
    y = data['Customer_Status']

    # Split data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Train Random Forest Model
    rf_model = RandomForestClassifier(n_estimators=100, random_state=42)
    rf_model.fit(X_train, y_train)

    # Evaluate Model
    y_pred = rf_model.predict(X_test)
    print("Confusion Matrix:")
    print(confusion_matrix(y_test, y_pred))
    print("\nClassification Report:")
    print(classification_report(y_test, y_pred))

    # Save the model and label encoders
    joblib.dump(rf_model, 'random_forest_model.pkl')
    joblib.dump(label_encoders, 'label_encoders.pkl')

    return rf_model, label_encoders, X.columns


def predict_churn(df_to_predict, model_path='random_forest_model.pkl', encoders_path='label_encoders.pkl'):
    """
    Predict churn for new customers
    
    Parameters:
    df_to_predict (pandas.DataFrame): Input dataframe with new customer data
    model_path (str): Path to saved Random Forest model
    encoders_path (str): Path to saved label encoders
    
    Returns:
    pandas.DataFrame: Original data with predicted churn status
    """
    # Load the model and label encoders
    rf_model = joblib.load(model_path)
    label_encoders = joblib.load(encoders_path)

    # Create a copy of the original data
    original_data = df_to_predict.copy()

    # Prepare data for prediction
    new_data = df_to_predict.drop(['Customer_ID', 'Customer_Status', 'Churn_Category', 'Churn_Reason'], axis=1)

    # Encode categorical variables using saved label encoders
    for column in new_data.select_dtypes(include=['object']).columns:
        new_data[column] = label_encoders[column].transform(new_data[column])

    # Make predictions
    new_predictions = rf_model.predict(new_data)

    # Add predictions to the original DataFrame
    original_data['Customer_Status_Predicted'] = new_predictions
    
    # Filter the DataFrame to include only records predicted as "Churned"
    churned_predictions = original_data[original_data['Customer_Status_Predicted'] == 1]

    # Save the results
    churned_predictions.to_csv("Predictions.csv", index=False)
    
    return churned_predictions
